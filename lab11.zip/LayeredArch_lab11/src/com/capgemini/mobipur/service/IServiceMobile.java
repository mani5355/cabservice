package com.capgemini.mobipur.service;

import java.util.List;

import com.capgemini.mobipur.bean.MobileBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;

public interface IServiceMobile {
	public List<MobileBean> viewAll() throws MobilePurchaseException;
	
	public boolean deleteMobile(final int mobileId)
			throws MobilePurchaseException;
	
	public List<MobileBean> search(final float minPrice, final float maxPrice)
			throws MobilePurchaseException;
	
}
