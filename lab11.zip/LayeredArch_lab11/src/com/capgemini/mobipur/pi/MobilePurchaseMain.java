package com.capgemini.mobipur.pi;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.mobipur.bean.MobileBean;
import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.service.ServiceMobileImpl;
import com.capgemini.mobipur.service.ServicePurchaseImpl;


public class MobilePurchaseMain {
	private static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		boolean isInProcess = true;
		boolean isValid = false;
		byte choice = 0;
		
		
		String cname = null;
		String mailId = null;
		String phoneNo =null;
		int mobileId = 0;
		PurchaseDetailsBean purchaseDetailsBean = null;
		ServiceMobileImpl serviceMobile = new ServiceMobileImpl();
		ServicePurchaseImpl servicePurchaseImpl =new ServicePurchaseImpl();
		
		List<MobileBean> mobileList = null;
		
		Scanner scInput = new Scanner(System.in);
		while(isInProcess){
			System.out.println("1)Insert Mobile Purchase.");
			System.out.println("2)View all mobiles.");
			System.out.println("3)Delete mobile Purchase");
			System.out.println("4)Search mobile for a range");
			System.out.println("0)exit.");
			choice = Byte.parseByte(scInput.nextLine());
			switch(choice){
			case 1:
				isValid = false;
				while(!isValid){
					try{
						System.out.println("Enter customer name: ");
						cname = scInput.nextLine();
					isValid = servicePurchaseImpl.isValidCName(cname);
					}catch(MobilePurchaseException mpr){
						logger.error("Invalid name: "+cname);
						System.err.println("Invalid name: "+cname);
						isValid = true;
					}
				}
				isValid = false;
				while(!isValid){
					try{
						System.out.println("Enter mail id: ");
						mailId = scInput.nextLine();
					isValid = servicePurchaseImpl.isValidMailId(mailId);
					}catch(MobilePurchaseException mpr){
						logger.error("Invalid mailId: " +mailId);
						System.err.println("Invalid mail id: "+mailId);
						isValid = true;
					}
				}
					isValid = false;
					while(!isValid){
						try{
							System.out.println("Enter phone no: ");
							phoneNo = scInput.nextLine();
						isValid = servicePurchaseImpl.isValidPhoneNo(phoneNo);
						}catch(MobilePurchaseException mpr){
							logger.error("Invalid phone no: "+phoneNo);
							System.err.println("Invalid phone number: "+phoneNo);
							isValid = true;
						}
					}
					isValid = false;
					while(!isValid){
						try{
							System.out.println("Enter Mobileid: ");
							mobileId = Integer.parseInt(scInput.nextLine());
						isValid = serviceMobile.isValidMobileId(mobileId);
						}catch(MobilePurchaseException mpr){
							logger.error("Invalid mobileId: "+mobileId);
							System.err.println("Invalid mobile id: "+mobileId);
							isValid = true;
						}
					}
					purchaseDetailsBean = new PurchaseDetailsBean(cname, mailId, phoneNo, mobileId);
					try{
						servicePurchaseImpl.insertPurchaseDetails(purchaseDetailsBean);
					}catch(MobilePurchaseException mpe){
						logger.error(mpe.getMessage());
					}
					break;
					
			case 2:
				try{
					mobileList = serviceMobile.viewAll();
					for (MobileBean mobileBean : mobileList) {
						System.out.println(mobileBean);
					}
					System.out.println("==============================================");
					
				}catch(MobilePurchaseException e){
				logger.error(e.getMessage());
				}
				break;
			case 3:
				isValid = false;
				while(!isValid){
					try{
						System.out.println("Enter Mobileid: ");
						mobileId = Integer.parseInt(scInput.nextLine());
					isValid = serviceMobile.isValidMobileId(mobileId);
					}catch(MobilePurchaseException mpr){
						logger.error("Invalid mobileId: "+mobileId);
						isValid = true;
					}
				}
				try {
					boolean isDeleted = serviceMobile.deleteMobile(mobileId);
					if(isDeleted){
						System.out.println("Mobile record deleted successfully!");
					}
				} catch (MobilePurchaseException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				float minPrice = 0;
				float maxPrice = 0;
				
				System.out.println("Enter minimum price: ");
				minPrice = Float.parseFloat(scInput.nextLine());
				
				System.out.println("Enter maxumum price: ");
				maxPrice = Float.parseFloat(scInput.nextLine());
				
				try {
					mobileList = serviceMobile.search(minPrice, maxPrice);
					for (MobileBean mobileBean : mobileList) {
						System.out.println(mobileBean);
					}
					System.out.println("=============================================");
				} catch (MobilePurchaseException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				}
				break;
			case 0:
				isInProcess = false;
				break;
			default:
					System.out.println("Invalid input");
					logger.error("Invalid input: "+ choice);
					break;
			}
		}
		scInput.close();
		
	}

}
