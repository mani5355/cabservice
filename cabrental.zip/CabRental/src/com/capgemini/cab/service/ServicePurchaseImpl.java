package com.capgemini.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bin.bean.PurchaseDetailsBean;
import com.capgemini.cab.dao.IMobileDAO;
import com.capgemini.cab.dao.IPurchaseDetailsDAO;
import com.capgemini.cab.dao.MobileDAOImpl;
import com.capgemini.cab.dao.PurchaseDetailsDAOImpl;
import com.capgemini.cab.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {
		int mobileQuantity = 0;
		boolean isItInserted = false;
	    boolean isUpdated = false;
		IPurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOImpl();
		IMobileDAO mobileDAO = new MobileDAOImpl();
		
		mobileQuantity = mobileDAO.getQuantity(purchaseDetailsBean.getMobileId());
		if(mobileQuantity > 0){
		isItInserted =
				purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
		mobileQuantity--;
		isUpdated = mobileDAO.updateMobile(purchaseDetailsBean.getMobileId(), mobileQuantity);
		
		}
		return (isItInserted &&isUpdated);
	}


public boolean isValidCName(String cname) throws MobilePurchaseException {
	boolean isValid = false;
String pattern = "[A-Z]{1}[A-Za-z]{1,19}";
Pattern ptn = Pattern.compile(pattern);
Matcher nameMatcher=ptn.matcher(cname);
isValid = nameMatcher.matches();//Pattern.matches(cname, pattern);
if(!isValid){
	throw new MobilePurchaseException("Invalid name");
}
return isValid;
}


public boolean isValidPhoneNo(String phoneNo) throws MobilePurchaseException {
	boolean isValid = false;
String pattern = "[\\d]{10}";
Pattern ptn = Pattern.compile(pattern);
Matcher nameMatcher=ptn.matcher(phoneNo);
isValid = nameMatcher.matches();
//isValid = Pattern.matches(phoneNo, pattern);
if(!isValid){
	throw new MobilePurchaseException("Phone no. must be 10 digits long");
}
return isValid;
}


public boolean isValidMailId(String mailId) throws MobilePurchaseException {
	boolean isValid = false;
String pattern = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";// + 	-> many times
Pattern ptn = Pattern.compile(pattern);
Matcher nameMatcher=ptn.matcher(mailId);
isValid = nameMatcher.matches();
//isValid = Pattern.matches(mailId, pattern);                 // \\. 	->its a dot, not represent singlechr
if(!isValid){
	throw new MobilePurchaseException("Invalid mailId");
}
return isValid;												// $ 	-> be in end
}
}