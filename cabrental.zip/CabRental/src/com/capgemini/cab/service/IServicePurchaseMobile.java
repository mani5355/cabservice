package com.capgemini.cab.service;

import com.capgemini.bin.bean.PurchaseDetailsBean;
import com.capgemini.cab.exception.MobilePurchaseException;

public interface IServicePurchaseMobile {
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
	throws MobilePurchaseException;
	
	
}
