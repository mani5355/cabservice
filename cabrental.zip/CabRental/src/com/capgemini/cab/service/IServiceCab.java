package com.capgemini.cab.service;

import com.capgemini.bin.bean.CustomerBean;
import com.capgemini.cab.exception.CabException;

public interface IServiceCab {
	public boolean addCustomer(final CustomerBean customerBean)
			throws CabException;
	
	public int getRequestID() throws CabException;
			
	public String bookCab(int requestId) throws CabException;
	
}
