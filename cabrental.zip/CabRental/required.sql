CREATE TABLE cab (cabid NUMBER PRIMARY KEY, name VARCHAR2 (20),pincode VARCHAR2(6), cab_number VARCHAR2(15));

INSERT INTO cab VALUES(1001,�Tata Indica�,'600157');
INSERT INTO cab VALUES(1003, 'Hyundai', '612157');
INSERT INTO cab VALUES(1002,�Mahindra�,'688157');

//TO DO � INSERT few more mobile details.
SELECT * FROM CAB

//CREATE TABLE cabcustomer(customerid NUMBER, name vARCHAR2(20), address VARCHAR2(30),
//phoneno VARCHAR2(12), regdate DATE, pin VARCHAR2(6));

CREATE TABLE cab_request(request_id NUMBER, customer_name VARCHAR2(20),
phone_number VARCHAR2(10), date_of_request DATE, request_status VARCHAR2(12),
cab_number VARCHAR2(15),address_of_pickup VARCHAR2(50),pincode VARCHAR2(6)
)

CREATE oR REPLACE SEQUENCE seq_request_id
START WITH 1;